package com.crazymike.api;

public class DISP {

    public static final String RNASC= "RNASC";//RN順排
    public static final String RNDESC= "RNDESC";//RN逆排
    public static final String TOP= "TOP";//置頂
    public static final String BUYASC= "BUYASC";//訂購灌水數順排
    public static final String BUYDESC= "BUYDESC";//訂購灌水數逆排
    public static final String PRICEASC= "PRICEASC";//售價順排
    public static final String PRICEDESC= "PRICEDESC";//售價逆排
    public static final String PRICE = "PRICE";
}
