package com.crazymike.api;

public class FUNC {

    public static final String APP_INDEX = "appIndex";
    public static final String APP_UP_SIDE_MENU = "appUpSideMenu";
    public static final String ITEM_LIST = "itemList";
    public static final String ITEM_DETAIL = "itemDetail";
    public static final String TRACE = "trace";
    public static final String APP_LEFT_SIDE_MENU = "appLeftSideMenu";
}
