package com.crazymike.api;

import android.util.Log;
import android.webkit.CookieManager;

import com.crazymike.api.service.Api;
import com.crazymike.api.service.AppApi2;
import com.crazymike.api.service.CartApi;
import com.crazymike.api.service.PromoteAPi;
import com.crazymike.api.service.ServerApi;
import com.crazymike.api.service.TraceApi;
import com.crazymike.api.service.TrackApi;
import com.crazymike.respositories.CookieRepository;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class NetworkService {

    public static final String TAG = "NetworkService";

    private static NetworkService INSTANCE;
    private final static int TIME_OUT_CONNECT = 30;
    private final static int TIME_OUT_READ = 30;
    private final static int TIME_OUT_WRITE = 30;

    public final Api api;
    private final CartApi cartApi;
    private final PromoteAPi promoteApi;
    private final AppApi2 appApi2;
    private final TrackApi trackApi;
    private final TraceApi traceApi;
    private final ServerApi serverApi;

    public static NetworkService getInstance() {
        return INSTANCE != null ? INSTANCE : (INSTANCE = new NetworkService());
    }

    private NetworkService() {

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.getCookie(URL.BASE);

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(message -> {
            if (isJsonValid(message)) {}
            else Log.i(TAG, message);
        });

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY))
                .connectTimeout(TIME_OUT_CONNECT, TimeUnit.SECONDS)
                .readTimeout(TIME_OUT_READ, TimeUnit.SECONDS)
                .writeTimeout(TIME_OUT_WRITE, TimeUnit.SECONDS)
                .cookieJar(CookieRepository.getInstance().getCookieJar())
//                .hostnameVerifier((hostname, session) -> true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(NonJsonConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(URL.BASE)
                .client(client)
                .build();

        api = retrofit.create(Api.class);
        cartApi = retrofit.create(CartApi.class);
        promoteApi = retrofit.create(PromoteAPi.class);
        appApi2 = retrofit.create(AppApi2.class);
        trackApi = retrofit.create(TrackApi.class);
        traceApi = retrofit.create(TraceApi.class);
        serverApi = retrofit.create(ServerApi.class);
    }

    public Api getProductApi() {
        return INSTANCE.api;
    }

    public CartApi getCartApi() {
        return INSTANCE.cartApi;
    }

    public PromoteAPi getPromoteApi() {
        return INSTANCE.promoteApi;
    }

    public AppApi2 getAppApi2() {
        return INSTANCE.appApi2;
    }

    public TrackApi getTrackApi() {
        return INSTANCE.trackApi;
    }

    public TraceApi getTraceApi() {
        return INSTANCE.traceApi;
    }

    public ServerApi getServerApi() {return INSTANCE.serverApi;}

    private boolean isJsonValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            try {
                new JSONArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

}
