package com.crazymike.api;

/**
 * Created by ChaoJen on 2016/11/18.
 */

public class TFUNC {
    public static final String ITEM = "item";
    public static final String TRACE = "trace";
}
