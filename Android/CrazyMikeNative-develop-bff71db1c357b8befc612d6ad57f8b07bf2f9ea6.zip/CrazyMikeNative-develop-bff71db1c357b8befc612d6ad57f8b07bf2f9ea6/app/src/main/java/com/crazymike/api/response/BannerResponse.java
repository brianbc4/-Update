package com.crazymike.api.response;

import com.crazymike.models.Banner;

import lombok.Getter;

@Getter
public class BannerResponse extends BaseResponse{

    private Banner rtn;
}
