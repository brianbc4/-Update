package com.crazymike.api.response;

public class CartsResponse extends BaseResponse{
}
