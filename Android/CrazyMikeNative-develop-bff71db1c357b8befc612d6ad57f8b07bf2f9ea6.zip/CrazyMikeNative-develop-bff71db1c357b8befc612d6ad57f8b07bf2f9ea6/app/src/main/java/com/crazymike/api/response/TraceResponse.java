package com.crazymike.api.response;

import lombok.Getter;

/**
 * Created by ChaoJen on 2016/11/18.
 */

@Getter
public class TraceResponse extends  BaseResponse {
    private boolean rtn;
}
