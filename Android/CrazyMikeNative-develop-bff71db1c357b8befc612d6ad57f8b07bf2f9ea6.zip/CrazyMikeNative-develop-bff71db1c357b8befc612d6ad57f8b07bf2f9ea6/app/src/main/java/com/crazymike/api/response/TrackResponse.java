package com.crazymike.api.response;

import lombok.Getter;

@Getter
public class TrackResponse extends BaseResponse{

    private boolean btn;
}
