package com.crazymike.cart;

public interface CartContract {

    interface View {

    }

    interface Presenter {

        void handleHTML(String html);
    }
}
