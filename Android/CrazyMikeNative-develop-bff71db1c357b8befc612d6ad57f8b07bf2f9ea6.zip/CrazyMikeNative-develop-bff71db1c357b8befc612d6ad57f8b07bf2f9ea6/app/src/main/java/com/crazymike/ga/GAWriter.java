package com.crazymike.ga;

import com.crazymike.models.UpSideMenu;
import com.crazymike.respositories.ProductRepository;
import com.crazymike.util.UrlParser;

public class GAWriter {

    public static String getLaunchMessage() {
        return "Launch";
    }

    public static String getPageMessage(int position, String url) {
        UpSideMenu currentUpSiMenu = ProductRepository.getInstance().getUpSideMenus().get(position);
        String tagId = position == 0 ? "5" : currentUpSiMenu.getUrl().split("tag-")[1].split("/")[0];
        String displayName = ProductRepository.getInstance().getUpSideMenus().get(position).getName();
        String params = UrlParser.getParams(url).length() > 0 ? String.format(".%s", UrlParser.getParams(url).replace("=", "-").replace("&", ".")) : "";
        String message = position == 0 ? "channel-5" : String.format("tag-%s-%s%s", tagId, displayName, params);
        return message;
    }

    public static String getItemMessage(String itemId) {
        return String.format("item-%s", itemId);
    }

    public static String getSearchMessage(String keyWord) {
        return "search-" + keyWord;
    }
}
