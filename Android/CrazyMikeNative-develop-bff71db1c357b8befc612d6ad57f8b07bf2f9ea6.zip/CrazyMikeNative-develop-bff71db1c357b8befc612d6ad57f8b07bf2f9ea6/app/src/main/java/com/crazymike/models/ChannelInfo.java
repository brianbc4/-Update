package com.crazymike.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by cuber on 2016/11/23.
 */

@Getter
@Setter
public class ChannelInfo {

    private String logo;
}
