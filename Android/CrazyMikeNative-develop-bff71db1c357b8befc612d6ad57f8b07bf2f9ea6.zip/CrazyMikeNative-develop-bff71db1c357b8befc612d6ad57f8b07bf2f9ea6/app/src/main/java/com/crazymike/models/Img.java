package com.crazymike.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by cuber on 16/9/19.
 */

@Getter
@Setter
public class Img {

    private String img_id;
    private String url;
}
