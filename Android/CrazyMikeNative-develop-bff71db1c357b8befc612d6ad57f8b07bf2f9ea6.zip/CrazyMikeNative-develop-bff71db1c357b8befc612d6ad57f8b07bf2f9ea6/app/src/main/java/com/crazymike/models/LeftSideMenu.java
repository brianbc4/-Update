package com.crazymike.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ChaoJen on 2016/12/8.
 */

@Getter
@Setter
public class LeftSideMenu {

    private String name;
    private String url;
    private int func;
}
