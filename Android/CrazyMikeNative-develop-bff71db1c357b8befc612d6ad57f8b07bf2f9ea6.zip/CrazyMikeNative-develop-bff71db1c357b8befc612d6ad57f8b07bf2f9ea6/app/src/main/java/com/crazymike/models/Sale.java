package com.crazymike.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ChaoJen on 2016/12/5.
 */

@Getter
@Setter
public class Sale {

    private String isale_id;
    private String qty;
    private String price_discount;
}
