package com.crazymike.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchHotKey {

    private String hotkey;
    private String url;
    private String m_url;
}
