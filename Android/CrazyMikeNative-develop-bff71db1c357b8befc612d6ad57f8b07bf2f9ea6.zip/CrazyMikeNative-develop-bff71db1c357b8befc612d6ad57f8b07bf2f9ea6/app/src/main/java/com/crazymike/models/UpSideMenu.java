package com.crazymike.models;

import lombok.Getter;

@Getter
public class UpSideMenu {
    private String name;
    private String url;
}
