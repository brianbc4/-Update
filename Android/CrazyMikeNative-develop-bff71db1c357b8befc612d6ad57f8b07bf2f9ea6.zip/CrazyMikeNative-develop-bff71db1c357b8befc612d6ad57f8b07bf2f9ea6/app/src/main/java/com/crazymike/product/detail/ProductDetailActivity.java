package com.crazymike.product.detail;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.crazymike.R;
import com.crazymike.api.URL;
import com.crazymike.base.BaseActivity;
import com.crazymike.login.LoginActivity;
import com.crazymike.main.MainActivity;
import com.crazymike.models.Cart;
import com.crazymike.models.General;
import com.crazymike.models.ItemDetail;
import com.crazymike.models.ItemList;
import com.crazymike.models.SearchHotKey;
import com.crazymike.product.detail.adapter.BaseProductDetailAdapter;
import com.crazymike.product.detail.adapter.NormalProductDetailAdapter;
import com.crazymike.product.detail.adapter.TravelProductDetailAdapter;
import com.crazymike.search.box.SearchDialogFragment;
import com.crazymike.search.result.SearchQueryActivity;
import com.crazymike.util.ActionName;
import com.crazymike.web.WebExtra;
import com.crazymike.web.WebViewActivity;
import com.crazymike.widget.OnScrollTopAndBottomListener;
import com.crazymike.widget.WrapContentGridLayoutManager;

import java.util.List;
import java.util.Map;

import static com.crazymike.main.MainActivity.WEB_REQUEST;

public class ProductDetailActivity extends BaseActivity implements ProductDetailContract.View, NormalProductDetailAdapter.onEvent, SearchDialogFragment.Listener {

    private static final String ITEM_ID = "ITEM_ID";
    private static final String TRAVEL_CHANNEL = "13";

    private ProductDetailPresenter presenter;
    private String itemId;
    private static ItemList mItemList;
    private static String itemURL;

    private ImageView icon;

    private BaseProductDetailAdapter adapter;
    private TextView cartBadge;
    private WebView webView;
    private RecyclerView recyclerView;
    private GridLayoutManager manager;

    public static void startActivity(Activity activity, ItemList itemList) {
        mItemList = itemList;
        itemURL = itemList.getItem_url();
        Intent intent = new Intent(activity, ProductDetailActivity.class);
        intent.putExtra(ITEM_ID, itemList.getItem_id());
        activity.startActivity(intent);
    }

    public static void startActivity(Activity activity, String itemID) {
        Intent intent = new Intent(activity, ProductDetailActivity.class);
        intent.putExtra(ITEM_ID, itemID);
        activity.startActivity(intent);
    }

    public static void startActivity(Activity activity, String itemID, String url) {
        Intent intent = new Intent(activity, ProductDetailActivity.class);
        intent.putExtra(ITEM_ID, itemID);
        intent.putExtra(WebExtra.URL, url);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Data
        itemId = getIntent().getStringExtra(ITEM_ID);
        presenter = new ProductDetailPresenter(this, itemId);

        //View
        setContentView(R.layout.activity_product_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        onCreateMenu(toolbar);
        setSupportActionBar(toolbar);
        toolbar.findViewById(R.id.back).setOnClickListener(v -> onBackPressed());
        toolbar.setNavigationOnClickListener(view -> finish());

        icon = (ImageView) findViewById(R.id.icon);
        if (presenter.hasSpecialLogo()) {
            Glide.with(this).load(presenter.getLogo()).into(icon);
        }

        //RecyclerView
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.addOnScrollListener(new OnScrollTopAndBottomListener().setOnBottomListener(() -> presenter.onScrollBottom()));
        manager = new WrapContentGridLayoutManager(this, 2);
        recyclerView.setLayoutManager(manager);
        //decide set ProductDetailAdapter with NormalProduct or TravelProduct
        adapter = mItemList == null || mItemList.getChannel().equals(TRAVEL_CHANNEL) ?
                new TravelProductDetailAdapter(this, this, manager, null, presenter.isTrack(itemId)) :
                new TravelProductDetailAdapter(this, this, manager, null, presenter.isTrack(itemId));
        recyclerView.setAdapter(adapter);

        //search
        findViewById(R.id.search).setOnClickListener(view -> onActionSearch());

        //webView for add cart api
        webView = new WebView(this);

        presenter.sendServerLog();
        presenter.sendGA(itemId);
        presenter.getItemDetail(itemId);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.getPromote(itemId);
        presenter.getCart();
    }

    @Override
    public void onCreateMenu(Toolbar toolbar) {

        //cart
        toolbar.findViewById(R.id.cart).setOnClickListener(view -> onActionCart());
        cartBadge = (TextView) toolbar.findViewById(R.id.cartBadge);
        cartBadge.setVisibility(View.GONE);
    }

    @Override
    public void onActionCart() {
        WebViewActivity.startActivity(this, URL.CART);
    }

    @Override
    public void onActionSearch() {
        SearchDialogFragment.newInstance().show(getSupportFragmentManager());
    }

    @Override
    public void onGetItemDetail(ItemDetail itemDetail) {
        adapter.setItemDetail(itemDetail);
        adapter.setIsTravelTag(presenter.isTravelTag(itemDetail.getInfo().getMain_tag()));
        presenter.countDown(itemDetail.getOnline().getDate_offline());
    }

    @Override
    public void onGetPromote(General general) {
        adapter.setGeneral(general);
    }

    @Override
    public void onGetItemDetailError(Throwable throwable) {
        throwable.printStackTrace();
    }

    @Override
    public void onGetPromoteError(Throwable throwable) {
        throwable.printStackTrace();
    }

    @Override
    public void onGetCart(Map<String, Cart> cartMap) {
        cartBadge.setVisibility(cartMap.size() == 0 ? View.GONE : View.VISIBLE);
        cartBadge.setText(String.valueOf(cartMap.size()));
    }

    @Override
    public void onGetCartCount(Integer count) {
        cartBadge.setVisibility(count == 0 ? View.GONE : View.VISIBLE);
        cartBadge.setText(String.valueOf(count));
        Toast toast = Toast.makeText(this, R.string.added_cart, Toast.LENGTH_SHORT);
        toast.getView().setBackgroundResource(R.color.colorPrimary);
        toast.getView().setPadding(20, 20, 20, 20);
        toast.show();
    }

    @Override
    public void onTrackChanged(boolean isTrack) {
        Toast toast = Toast.makeText(this, isTrack ? R.string.added_track : R.string.deleted_track, Toast.LENGTH_SHORT);
        toast.getView().setBackgroundResource(R.color.colorPrimary);
        toast.getView().setPadding(20, 20, 20, 20);
        toast.show();
        adapter.setTrack(isTrack);
    }

    @Override
    public void onTimerCountDown(int sec) {
        adapter.setCountDownTime(sec);
    }

    @Override
    public void onGetItemList(List<ItemList> itemLists) {
        adapter.setItemList(itemLists);
    }

    @Override
    public void showProgress() {
        findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        findViewById(R.id.progressBar).setVisibility(View.GONE);
    }

    @Override
    public void onAddToCartClick() {
        //Because api can't get the cookie "cart2" , it never show item in cart web
        //And Server side is XXX always XXX
        //So I just use webView to post the api, and native api to get cart count
        webView.loadUrl(URL.ADD_CART + "&item_id=" + itemId);
        presenter.addToCart(itemId);
    }

    @Override
    public void onBuyClick() {
        WebViewActivity.startActivity(this, presenter.getBuyNewUrl(itemId));
    }

    @Override
    public void onTrackClick() {
        if (presenter.isLogin()) {
            presenter.addTrack(itemId);
        } else {
            LoginActivity.startActivity(this);
        }
    }


    @Override
    public void shareItem() {
        presenter.shareItem(this, itemURL);
    }


    @Override
    public void onItemListClick(ItemList itemList) {
        ProductDetailActivity.startActivity(this, itemList.getItem_id());
    }

    @Override
    public void onExpandClick() {
        recyclerView.scrollToPosition(3);
    }

    @Override
    public void onPageSelected() {
        recyclerView.scrollToPosition(3);
    }

    @Override
    public void onBannerClick(General general) {

//        MaterialDialog dialog = new MaterialDialog.Builder(this)
//                .customView(R.layout.dialog_promote, false)
//                .build();
//
//        TextView content = (TextView) dialog.findViewById(R.id.content);
//        StringBuilder sb = new StringBuilder();
//
//        if (general.getPassword() != null && general.getPassword().size() > 0) {
//            sb.append(getString(R.string.checkout_input));
//            sb.append(getString(R.string.promote_password));
//            sb.append(",");
//            ((BannerHolder) holder).password.setVisibility(View.VISIBLE);
//            ((BannerHolder) holder).password.setText(general.getPassword().get(0));
//            ((BannerHolder) holder).type.setText(R.string.checkout_input);
//        } else {
//            ((BannerHolder) holder).password.setVisibility(View.GONE);
//        }
//
//        switch (general.getDiscType()) {
//            case 1:
//                sb.
//                ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_1), general.getDiscPromote()));
//                ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_1));
//                break;
//
//            case 2:
//                ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_2), general.getDiscCash().get(0), general.getDiscCash().get(1)));
//                ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_2));
//                break;
//
//            case 3:
//                ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_3), general.getDiscCash()));
//                ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_3));
//                break;
//        }
//
//
//
//        ((BannerHolder) holder).itemView.setOnClickListener(view -> event.onBannerClick(general));
//
//
//        //password
//        View passwordLayout = dialog.findViewById(R.id.passwordLayout);
//
//
//        if (general.getPassword() != null && general.getPassword().size() > 0 && general.getIsMember()) {
//            passwordLayout.setVisibility(View.VISIBLE);
//            ((TextView) dialog.findViewById(R.id.password)).setText(general.getPassword().get(0));
//            dialog.findViewById(R.id.copy).setOnClickListener(view -> {
//
//            });
//        } else {
//            passwordLayout.setVisibility(View.GONE);
//        }
//
//        content.setText(String.format(getString(R.string.promote_content_1), general.getDiscPromote()));
//        //content
//        StringBuilder builder = new StringBuilder();
//        builder.append(String.format(getString(R.string.promote_content), general.getPassword().get(0), general.getDiscPromote()));
//        if (general.getIsMember()) {
//            builder.append(String.format("(%s)", getString(R.string.only_member)));
//        }
//
//        ((TextView) dialog.findViewById(R.id.offDate)).setText(general.getDateOffline());
//        RecyclerView recyclerView = (RecyclerView) dialog.findViewById(R.id.recyclerView);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
//        recyclerView.setAdapter(new GeneralTagAdapter(this, general.getTag()));
//        dialog.show();
    }


    @Override
    public void OnHotKeyClick(SearchHotKey searchHotKey) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setAction(ActionName.SEARCH_KEY);
        intent.putExtra(ActionName.SEARCH_KEY, searchHotKey.getHotkey());
        startActivity(intent);
    }

    @Override
    public void OnGetSearchKey(String search) {
        SearchQueryActivity.startActivity(this, search);
    }

    @Override
    public void showWebView(String item_url) {
        WebViewActivity.startActivity(this, item_url, WEB_REQUEST);
    }


}
