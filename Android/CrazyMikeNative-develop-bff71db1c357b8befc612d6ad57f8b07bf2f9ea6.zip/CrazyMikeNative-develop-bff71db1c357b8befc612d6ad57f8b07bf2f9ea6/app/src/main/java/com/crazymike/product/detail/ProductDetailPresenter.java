package com.crazymike.product.detail;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.crazymike.api.URL;
import com.crazymike.ga.GAWriter;
import com.crazymike.models.General;
import com.crazymike.models.ItemDetail;
import com.crazymike.models.ItemList;
import com.crazymike.respositories.CartRepository;
import com.crazymike.respositories.CookieRepository;
import com.crazymike.respositories.ProductRepository;
import com.crazymike.respositories.PromoteRepository;
import com.crazymike.respositories.TrackRepository;
import com.crazymike.ga.GASender;
import com.crazymike.trace.ServerLog;
import com.crazymike.trace.UserBehaviorTracer;
import com.crazymike.util.RxUtil;
import com.crazymike.web.WebExtra;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.RxLifecycle;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;

class ProductDetailPresenter implements ProductDetailContract.Presenter {

    private static final String TAG = ProductDetailPresenter.class.getSimpleName();
    private ProductDetailContract.View view;
    private Subscription timeSubscription;
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:ss:mm", Locale.TAIWAN);
    private int page = 0;
    private ItemDetail itemDetail;
    private List<ItemList> itemLists = new ArrayList<>();


    ProductDetailPresenter(ProductDetailContract.View view, String itemId) {
        this.view = view;
        CartRepository.getInstance().getCartObservable()
                .compose(RxUtil.bindLifecycle(view))
                .subscribe(view::onGetCart, Throwable::printStackTrace);

        CartRepository.getInstance().getCartCountObservable()
                .compose(RxUtil.bindLifecycle(view))
                .subscribe(view::onGetCartCount, Throwable::printStackTrace);

        TrackRepository.getInstance().getTrackAddOrDelObservable()
                .compose(RxUtil.bindLifecycle(view))
                .subscribe(view::onTrackChanged, Throwable::printStackTrace);
    }

    @Override
    public void getItemDetail(String itemId) {
        view.showProgress();
        ProductRepository.getInstance().getItemDetail(itemId)
                .compose(RxUtil.mainAsync())
                .compose(RxUtil.bindLifecycle(view))
                .doAfterTerminate(() -> view.hideProgress())
                .subscribe(itemDetail -> {
                    this.itemDetail = itemDetail;
                    view.onGetItemDetail(itemDetail);
                    new UserBehaviorTracer().onItemDetailDisplay(itemDetail);
                }, throwable -> view.onGetItemDetailError(throwable));
    }


    @Override
    public void getPromote(String itemId) {
        PromoteRepository.getInstance().getPromote(itemId)
                .compose(RxUtil.mainAsync())
                .compose(RxUtil.bindLifecycle(view))
                .subscribe(general -> {

//                    if (general != null) view.onGetPromote(general);


                    General g = new General();
                    g.setIsMember(true);
                    g.setDiscType(1);

                    g.setDiscPromote("88");

                    List<String> discCash = new ArrayList<>();
                    discCash.add("可折抵50元");
                    discCash.add("滿500元時");
                    g.setDiscCash(discCash);

                    List<String> password = new ArrayList<>();
                    password.add("Cuber5566");
                    g.setPassword(password);

                    List<General.Tag> tags = new ArrayList<>();
                    tags.add(new General.Tag("限3C周邊", true));
                    tags.add(new General.Tag("限行動賣客", true));
                    tags.add(new General.Tag("部分商品除外", true));
                    g.setTag(tags);

                    view.onGetPromote(g);

                    g.setDateOffline("2016/10/31");

                }, throwable -> view.onGetPromoteError(throwable));
    }

    @Override
    public void getCart() {
        CartRepository.getInstance().callCartMap();
    }

    @Override
    public String getBuyNewUrl(String itemId) {
        Uri uri = new Uri.Builder()
                .path(URL.BUY)
                .appendQueryParameter("item_id", itemId)
                .build();
        return uri.toString();
    }

    @Override
    public boolean isLogin() {
        return CookieRepository.getInstance().isLogin();
    }

    @Override
    public boolean isTrack(String itemId) {
        return TrackRepository.getInstance().isIn(itemId);
    }

    @Override
    public void addToCart(String itemId) {
        CartRepository.getInstance().addCart(itemId);
    }

    @Override
    public void addTrack(String itemId) {
        if (TrackRepository.getInstance().isIn(itemId)) {
            TrackRepository.getInstance().delTrack(itemId);
        } else {
            TrackRepository.getInstance().addTrack(itemId);
        }
    }

    @Override
    public void buy(ItemDetail itemDetail) {

    }


    @Override
    public void countDown(String date_offline) {

        long sec = getTime(date_offline);
        long now = new Date().getTime();
        timeSubscription = Observable.interval(1, TimeUnit.SECONDS)
                .compose(RxUtil.mainAsync())
                .compose(RxLifecycle.bindUntilEvent(((RxAppCompatActivity) view).lifecycle(), ActivityEvent.CREATE))
                .map(time -> ((sec - now) / 1000) - time)
                .subscribe(time -> {
                    if (time < 1) stopTimer();
                    view.onTimerCountDown(time.intValue());
                }, Throwable::printStackTrace);
    }

    @Override
    public void stopTimer() {
        if (timeSubscription == null) return;
        timeSubscription.unsubscribe();
        timeSubscription = null;
        view.onTimerCountDown(0);
    }

    @Override
    public void getItemList() {
        view.showProgress();
        ProductRepository.getInstance().callItemListByChannel(itemDetail.getInfo().getChannel_id(), page)
                .compose(RxUtil.mainAsync())
                .compose(RxUtil.bindLifecycle(view))
                .doAfterTerminate(() -> view.hideProgress())
                .subscribe(this::handleItemListResponse, Throwable::printStackTrace);
    }

    @Override
    public void handleItemListResponse(List<ItemList> items) {
        itemLists.addAll(items);
        view.onGetItemList(itemLists);
    }

    @Override
    public void onScrollBottom() {
        page++;
        getItemList();
    }

    @Override
    public void sendServerLog() {
        String url = "";
        try {
            url = ((ProductDetailActivity) view).getIntent().getStringExtra(WebExtra.URL);
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
        new ServerLog().send(url);
    }

    @Override
    public void sendGA(String itemId) {
        GASender.sendScreenView(GAWriter.getItemMessage(itemId));
    }

    @Override
    public boolean hasSpecialLogo() {
        return ProductRepository.getInstance().hasSpecialLogo();
    }

    @Override
    public String getLogo() {
        return ProductRepository.getInstance().getChannelInfo().getLogo();
    }

    @Override
    public boolean isTravelTag(String tagId) {
        return ProductRepository.getInstance().checkIsTravelTag(tagId);
    }

    private long getTime(String date) {
        try {
            return format.parse(date).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    void shareItem(Activity activity, String itemURL) {

        Intent sendIntent = new Intent();
        String itemName = itemDetail.getInfo().getName();
        String shareContent = itemName + "\n" + itemURL;
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TEXT, shareContent);

        activity.startActivity(Intent.createChooser(sendIntent, itemName));
    }
}
