package com.crazymike.product.detail.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.crazymike.R;
import com.crazymike.models.Img;
import com.crazymike.models.ItemDetail;
import com.crazymike.models.ItemList;
import com.crazymike.product.detail.alert.SalesDialog;
import com.crazymike.widget.CircleIndicator;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class NormalProductDetailAdapter extends BaseProductDetailAdapter {

    private static final int SECTION_COUNT = 7;

    private List<ProductInfoHolder> countDownViewList;

    public void setCountDownTime(int sec) {
        for (ProductInfoHolder holder : countDownViewList) {
            int h = (sec / 3600) % 24;
            int m = (sec % 3600) / 60;
            int s = sec % 3600 % 60;
            holder.textViewCountDown.setText(String.format("%s %s %s %s %s %s %s", surplusString, h, hourString, m, minuteString, s, secondString));
        }
    }

    public NormalProductDetailAdapter(Context context, onEvent event, GridLayoutManager manager, ItemDetail itemDetail, boolean isTrack) {
        countDownViewList = new ArrayList<>();
        this.context = context;
        this.event = event;
        this.itemDetail = itemDetail;
        this.isTrack = isTrack;
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return position < SECTION_COUNT ? manager.getSpanCount() : 1;
            }
        });
        init(context);
    }

    @Override
    public int getItemCount() {
        if (itemDetail == null) return 0;
        return SECTION_COUNT + items.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (general == null) position += 1;
        switch (position) {
            case 0:
                return TYPE_TITLE;
            case 1:
                return TYPE_IMAGE;
            case 2:
                return TYPE_PRICE;
            case 3:
                return TYPE_PRODUCT_INFO;
            case 4:
                return TYPE_SALES;
            case 5:
                return TYPE_SECOND;
            case 6:
                return TYPE_ITEM_HEADER;
            default:
                return TYPE_ITEM_LIST;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        switch (viewType) {
            case TYPE_BANNER:
                return new BannerHolder(inflater.inflate(R.layout.item_product_detail_banner, parent, false));
            case TYPE_TITLE:
                return new TitleHolder(inflater.inflate(R.layout.item_product_detail_title, parent, false));
            case TYPE_PRICE:
                return new PriceHolder(inflater.inflate(R.layout.item_product_detail_price, parent, false));
            case TYPE_COUNT_DOWN:
                return new CountDownHolder(inflater.inflate(R.layout.item_product_detail_travel_count_down, parent, false));
            case TYPE_IMAGE:
                return new ImageHolder(inflater.inflate(R.layout.item_product_detail_image, parent, false));
            case TYPE_SECOND:
                return new SecondHolder(inflater.inflate(R.layout.item_product_detail_second, parent, false));
            case TYPE_PRODUCT_INFO:
                return new ProductInfoHolder(inflater.inflate(R.layout.item_product_detail_info, parent, false));
            case TYPE_SALES:
                return new SalesHolder(inflater.inflate(R.layout.item_product_detail_sales, parent, false));
            case TYPE_ITEM_HEADER:
                return new ItemListHeader(inflater.inflate(R.layout.item_product_detail_item_header, parent, false));
            case TYPE_ITEM_LIST:
            default:
                return new ItemListHolder(inflater.inflate(R.layout.holder_item_grid, parent, false));
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);

        if (holder instanceof CountDownHolder) {
            countDownViewList.remove(holder);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof BannerHolder && general != null) {

            ((BannerHolder) holder).click.setText(R.string.click_see_detail);
            ((BannerHolder) holder).isMember.setVisibility(general.getIsMember() ? View.VISIBLE : View.GONE);

            switch (general.getDiscType()) {
                case 1:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_1), general.getDiscPromote()));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_1));
                    break;

                case 2:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_2), general.getDiscCash().get(0), general.getDiscCash().get(1)));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_2));
                    break;

                case 3:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_3), general.getDiscCash()));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_3));
                    break;
            }

            if (general.getPassword() != null && general.getPassword().size() > 0) {
                ((BannerHolder) holder).password.setVisibility(View.VISIBLE);
                ((BannerHolder) holder).password.setText(general.getPassword().get(0));
                ((BannerHolder) holder).type.setText(R.string.checkout_input);
            } else {
                ((BannerHolder) holder).password.setVisibility(View.GONE);
            }

            ((BannerHolder) holder).itemView.setOnClickListener(view -> event.onBannerClick(general));

        } else if (holder instanceof TitleHolder) {
            TitleHolder titleHolder = (TitleHolder) holder;

            //name
            String titleDiscount = !discount.equals("") && info.getIs_hilife() != null && info.getIs_hilife().equals("t") ? String.format("%s%s%s!", downDiscount, discountString, discString) : "";
            Spannable spannable = new SpannableString(titleDiscount + info.getName());
            spannable.setSpan(new ForegroundColorSpan(Color.RED), 0, titleDiscount.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            titleHolder.name.setText(spannable, TextView.BufferType.SPANNABLE);

            //sub title
            titleHolder.textViewSubTitle.setText(info.getSubtitle());

        } else if (holder instanceof PriceHolder) {
            PriceHolder priceHolder = (PriceHolder) holder;

            //price
            if(info.getPrice_title() != Integer.valueOf(info.getPrice())) {
                priceHolder.price.setText(String.format("$%s ~ $%s", info.getPrice_title(), info.getPrice()));
            } else {
                priceHolder.price.setText(String.format("$%s", info.getPrice_title() > 0 ? info.getPrice_title() : info.getPrice()));
            }

            //notaxString
            if (info.getWithout_is_notax() != null && info.getWithout_is_notax().equals("t")) {
                priceHolder.notax.setText(String.format("%s$%s", notaxString, info.getWithout_notax_price()));
            } else {
                priceHolder.notax.setVisibility(View.GONE);
            }

            //bonus amt
            if (info.getBonus_amt() == 0) {
                priceHolder.linearLayoutBonus.setVisibility(View.GONE);
            } else {
                priceHolder.linearLayoutBonus.setVisibility(View.VISIBLE);
                priceHolder.bonusAmt.setText(String.format(bonusAmtString, info.getBonus_amt()));
            }

            //coupons
            priceHolder.linearLayoutCoupon.setVisibility(
                    info.getIs_no_coupons().equals("t") ? View.GONE : View.VISIBLE);

            //priceFakeString
            priceHolder.priceFake.setText(String.format("$%s", info.getPrice_fake()));
            priceHolder.priceFake.setPaintFlags(priceHolder.priceFake.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            Paint paint = priceHolder.priceFake.getPaint();
            paint.setColor(context.getResources().getColor(R.color.black_text_secondary));
            paint.setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            paint.setAntiAlias(true);

            //sales
            priceHolder.imageViewSales.setVisibility(itemDetail.getSales().size() > 0 ? View.VISIBLE : View.GONE);
            priceHolder.relativeLayoutRoot.setOnClickListener(view -> {
                if (itemDetail.getSales().size() > 0) showSalesDialog();
            });

            //i want buy
            priceHolder.iWantBuy.setVisibility(position == 2 && online.getIs_stock() && !(getTime(online.getDate_online()) > date.getTime()) ? View.VISIBLE : View.GONE);
            priceHolder.iWantBuy.setOnClickListener(view -> {
                if (online.getIs_stock()) event.onBuyClick();
            });

        } else if (holder instanceof CountDownHolder) {

            String buyItems = info.getBuy_items();
            Spannable buyIteSpannable = new SpannableString(String.format("%s %s / ", favorString, buyItems));
            buyIteSpannable.setSpan(new ForegroundColorSpan(Color.RED), favorString.length(), favorString.length() + buyItems.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            ((CountDownHolder) holder).buyItems.setText(buyIteSpannable);


        } else if (holder instanceof ImageHolder) {

            List<Img> imgList = new ArrayList<>();
            Img img = new Img();
            img.setUrl(info.getImg1_url());
            imgList.add(img);


            if (itemDetail.getImg() != null && itemDetail.getImg().size() != 0) {
                imgList.addAll(itemDetail.getImg());
                ((ImageHolder) holder).imgViewPager.setAdapter(new ImgPagerAdapter(context, imgList));
                ((ImageHolder) holder).indicator.setViewPager(((ImageHolder) holder).imgViewPager);
            } else {
                ((ImageHolder) holder).imgViewPager.setAdapter(new ImgPagerAdapter(context, imgList));
                ((ImageHolder) holder).indicator.setVisibility(View.GONE);
            }

        } else if (holder instanceof SecondHolder) {

            ((SecondHolder) holder).addToCart.setVisibility(View.GONE);
            ((SecondHolder) holder).buyNow.setVisibility(View.GONE);
            ((SecondHolder) holder).nextTime.setVisibility(View.GONE);
            ((SecondHolder) holder).notSale.setVisibility(View.GONE);
            ((SecondHolder) holder).contact.setVisibility(View.GONE);

            ((SecondHolder) holder).addToCart.setOnClickListener(view -> event.onAddToCartClick());
            ((SecondHolder) holder).buyNow.setOnClickListener(view -> event.onBuyClick());

            if (online.getIs_stock() && getTime(online.getDate_online()) <= date.getTime()) {

                if (!online.getChannel_id().equals("13") && !info.getIs_hilife_shop().equals("t")) {
                    ((SecondHolder) holder).addToCart.setVisibility(View.VISIBLE);
                }

                if (isTravelTag || (itemDetail.getInfo().getIs_hilife_shop() != null && itemDetail.getInfo().getIs_hilife_shop().equals("t"))) {
                    ((SecondHolder) holder).addToCart.setVisibility(View.GONE);
                }

                if (online.getChannel_id().equals("13")) {
                    ((SecondHolder) holder).contact.setVisibility(View.VISIBLE);
                }

                ((SecondHolder) holder).buyNow.setVisibility(View.VISIBLE);
            } else if (online.getIs_stock() && getTime(online.getDate_online()) > date.getTime()) {
                ((SecondHolder) holder).notSale.setVisibility(View.VISIBLE);
            } else {
                ((SecondHolder) holder).nextTime.setVisibility(View.VISIBLE);
            }

        } else if (holder instanceof ProductInfoHolder) {

            ProductInfoHolder productInfoHolder = (ProductInfoHolder) holder;

            productInfoHolder.linearLayoutTabDesc.setOnClickListener(view -> selectPage(productInfoHolder, view));
            productInfoHolder.linearLayoutTabSpecification.setOnClickListener(view -> selectPage(productInfoHolder, view));
            productInfoHolder.linearLayoutTabReturn.setOnClickListener(view -> selectPage(productInfoHolder, view));

            countDownViewList.add(((ProductInfoHolder) holder));
            productInfoHolder.textViewBuyItems.setText(String.valueOf(info.getBuy_items()));

            productInfoHolder.imageViewFavorite.setImageResource(isTrack ? R.mipmap.like_active : R.mipmap.like64x64);
            productInfoHolder.linearLayoutFavorite.setOnClickListener(view -> event.onTrackClick());
            productInfoHolder.linearLayoutShare.setOnClickListener(view -> event.shareItem());
            productInfoHolder.textViewProductId.setText(String.format("%s: %s", context.getResources().getString(R.string.product_id), itemDetail.getOnline().getItem_id()));

            Spanned html;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                html = Html.fromHtml(itemDetail.getDeliver_notic(), Html.FROM_HTML_MODE_LEGACY);
            } else {
                html = Html.fromHtml(itemDetail.getDeliver_notic());
            }

            productInfoHolder.deliverNotice.setText(html);

            settingYoutubeWebView(productInfoHolder.youtube1, info.getYoutube_url1());
            settingYoutubeWebView(productInfoHolder.youtube2, info.getYoutube_url2());
            settingWebView(productInfoHolder.content, info.getContent());
            settingWebView(productInfoHolder.buyReason, info.getBuy_reason());

            if (info.getMade_in() != null && !info.getMade_in().equals("")) {
                productInfoHolder.madeIn.setText(info.getMade_in());
            }

            if (info.getItem_state() != null && !info.getItem_state().equals("")) {
                productInfoHolder.itemState.setText(info.getItem_state());
            }

            settingWebView(productInfoHolder.specification, info.getSpecification());
            settingWebView(productInfoHolder.returnNotice, itemDetail.getReturn_notice());

        } else if (holder instanceof SalesHolder) {
            SalesHolder salesHolder = (SalesHolder) holder;

            salesHolder.cardViewSales.setVisibility(itemDetail.getSales().size() > 0 ? View.VISIBLE : View.GONE);

            salesHolder.recyclerViewSales.setLayoutManager(new LinearLayoutManager(context));
            salesHolder.recyclerViewSales.setAdapter(new SalesAdapter(context, itemDetail));

            salesHolder.linearLayoutMore.setVisibility(itemDetail.getSales().size() > 3 ? View.VISIBLE : View.GONE);
            salesHolder.linearLayoutMore.setOnClickListener(view -> showSalesDialog());

        } else if (holder instanceof ItemListHolder) {

            int itemPosition = position - SECTION_COUNT;
            if (itemPosition < 0 || items == null || items.size() == 0) return;

            ItemList itemList = items.get(itemPosition);

            String imgUrl = itemList.getPimg_m() == null || itemList.getPimg_m().equals("") ? itemList.getPimg_m() : itemList.getPimg();
            Glide.with(context).load(imgUrl)
                    .centerCrop()
                    .placeholder(R.mipmap.bg_download)
                    .into(((ItemListHolder) holder).thumb);

            ((ItemListHolder) holder).stock.setVisibility(itemList.getStock().equals("0") || itemList.getStock().equals("") ? View.VISIBLE : View.GONE);

            ((ItemListHolder) holder).name.setText(itemList.getPname());
            ((ItemListHolder) holder).priceFake.setText(String.format("$%s", itemList.getPrice_fake()));
            Paint paint = ((ItemListHolder) holder).priceFake.getPaint();
            paint.setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            paint.setAntiAlias(true);

            if (itemList.getPrice_title() != null && !itemList.getPrice_title().equals("0") && itemList.getIs_priceup().equals("1")) {
                ((ItemListHolder) holder).priceUp.setVisibility(View.VISIBLE);
                ((ItemListHolder) holder).priceTitle.setText(String.format("$%s", itemList.getPrice_title()));
            } else {
                ((ItemListHolder) holder).priceUp.setVisibility(View.GONE);
                ((ItemListHolder) holder).priceTitle.setText(String.format("$%s", itemList.getPrice()));
            }

            holder.itemView.setOnClickListener(v -> event.onItemListClick(itemList));
        }
    }

    private void showSalesDialog() {
        new SalesDialog(context, itemDetail).showDialog();
    }

    private void selectPage(ProductInfoHolder productInfoHolder, View view) {
        //tab
        productInfoHolder.textViewTabDesc.setTextColor(
                view.getId() == R.id.linear_layout_tab_desc ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.tab_text_unselected));
        productInfoHolder.textViewTabSpecification.setTextColor(
                view.getId() == R.id.linear_layout_tab_specification ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.tab_text_unselected));
        productInfoHolder.textViewTabReturn.setTextColor(
                view.getId() == R.id.linear_layout_tab_return ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.tab_text_unselected));

        //under line
        productInfoHolder.linearLayoutUnderLineDesc.setBackgroundColor(
                view.getId() == R.id.linear_layout_tab_desc ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.grey_alpha25));
        productInfoHolder.linearLayoutUnderLineSpecification.setBackgroundColor(
                view.getId() == R.id.linear_layout_tab_specification ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.grey_alpha25));
        productInfoHolder.linearLayoutUnderLineReturn.setBackgroundColor(
                view.getId() == R.id.linear_layout_tab_return ? context.getResources().getColor(R.color.tab_text_selected) : context.getResources().getColor(R.color.grey_alpha25));

        //page
        productInfoHolder.linearLayoutPageDesc.setVisibility(
                view.getId() == R.id.linear_layout_tab_desc ? View.VISIBLE : View.GONE);
        productInfoHolder.linearLayoutPageSpecification.setVisibility(
                view.getId() == R.id.linear_layout_tab_specification ? View.VISIBLE : View.GONE);
        productInfoHolder.linearLayoutPageReturn.setVisibility(
                view.getId() == R.id.linear_layout_tab_return ? View.VISIBLE : View.GONE);

        event.onPageSelected();
    }

    class BannerHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.type) TextView type;
        @BindView(R.id.password) TextView password;
        @BindView(R.id.content) TextView content;
        @BindView(R.id.click) TextView click;
        @BindView(R.id.isMember) TextView isMember;

        BannerHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class TitleHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.name) TextView name;
        @BindView(R.id.text_view_sub_title) TextView textViewSubTitle;

        TitleHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class PriceHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.relative_layout_root) RelativeLayout relativeLayoutRoot;
        @BindView(R.id.price) TextView price;
        @BindView(R.id.notax) TextView notax;
        @BindView(R.id.priceFake) TextView priceFake;
        @BindView(R.id.image_view_sales) ImageView imageViewSales;
        @BindView(R.id.iWantBuy) Button iWantBuy;
        @BindView(R.id.linear_layout_bonus) LinearLayout linearLayoutBonus;
        @BindView(R.id.bonusAmt) TextView bonusAmt;
        @BindView(R.id.bonusAmtUp) TextView bonusAmtUp;
        @BindView(R.id.linear_layout_coupon) LinearLayout linearLayoutCoupon;

        PriceHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class CountDownHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.text_view_buy_items) TextView buyItems;
        @BindView(R.id.text_view_count_down) TextView countDown;

        CountDownHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ImageHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgViewPager) ViewPager imgViewPager;
        @BindView(R.id.indicator) CircleIndicator indicator;

        ImageHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class SecondHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.addToCart) Button addToCart;
        @BindView(R.id.buyNow) Button buyNow;
        @BindView(R.id.notSale) TextView notSale;
        @BindView(R.id.nextTime) Button nextTime;
        @BindView(R.id.contact) View contact;

        SecondHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ProductInfoHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.linear_layout_tab_desc) LinearLayout linearLayoutTabDesc;
        @BindView(R.id.linear_layout_tab_specification) LinearLayout linearLayoutTabSpecification;
        @BindView(R.id.linear_layout_tab_return) LinearLayout linearLayoutTabReturn;

        @BindView(R.id.linear_layout_page_desc) LinearLayout linearLayoutPageDesc;
        @BindView(R.id.linear_layout_page_specification) LinearLayout linearLayoutPageSpecification;
        @BindView(R.id.linear_layout_page_return) LinearLayout linearLayoutPageReturn;

        @BindView(R.id.text_view_tab_desc) TextView textViewTabDesc;
        @BindView(R.id.text_view_tab_specification) TextView textViewTabSpecification;
        @BindView(R.id.text_view_tab_return) TextView textViewTabReturn;

        @BindView(R.id.linear_layout_under_line_desc) LinearLayout linearLayoutUnderLineDesc;
        @BindView(R.id.linear_layout_under_line_specification) LinearLayout linearLayoutUnderLineSpecification;
        @BindView(R.id.linear_layout_under_line_return) LinearLayout linearLayoutUnderLineReturn;

        @BindView(R.id.linear_layout_favorite) LinearLayout linearLayoutFavorite;
        @BindView(R.id.linear_layout_share) LinearLayout linearLayoutShare;
        @BindView(R.id.image_view_favorite) ImageView imageViewFavorite;
        @BindView(R.id.text_view_buy_items) TextView textViewBuyItems;
        @BindView(R.id.text_view_count_down) TextView textViewCountDown;
        @BindView(R.id.text_view_product_id) TextView textViewProductId;

        @BindView(R.id.expectDeliverLayout) View expectDeliverLayout;
        @BindView(R.id.deliverNotice) TextView deliverNotice;
        @BindView(R.id.youtobe1) WebView youtube1;
        @BindView(R.id.youtobe2) WebView youtube2;
        @BindView(R.id.content) WebView content;
        @BindView(R.id.buyReason) WebView buyReason;
        @BindView(R.id.madeIn) TextView madeIn;
        @BindView(R.id.itemState) TextView itemState;
        @BindView(R.id.specification) WebView specification;
        @BindView(R.id.returnNotice) WebView returnNotice;

        ProductInfoHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class SalesHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.card_view_sales) CardView cardViewSales;
        @BindView(R.id.recycler_view_sales) RecyclerView recyclerViewSales;
        @BindView(R.id.linear_layout_more) LinearLayout linearLayoutMore;

        public SalesHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ItemListHeader extends RecyclerView.ViewHolder {

        ItemListHeader(View itemView) {
            super(itemView);
        }
    }

    class ItemListHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.thumb) ImageView thumb;
        @BindView(R.id.stock) ImageView stock;
        @BindView(R.id.name) TextView name;
        @BindView(R.id.priceFake) TextView priceFake;
        @BindView(R.id.priceTitle) TextView priceTitle;
        @BindView(R.id.priceUp) TextView priceUp;

        ItemListHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
