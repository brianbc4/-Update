package com.crazymike.product.detail.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.crazymike.R;
import com.crazymike.models.Img;
import com.crazymike.models.ItemDetail;
import com.crazymike.models.ItemList;
import com.crazymike.widget.CircleIndicator;

import java.util.ArrayList;
import java.util.List;

public class TravelProductDetailAdapter extends BaseProductDetailAdapter {

    private static final int SECTION_COUNT = 10;

    private List<CountDownHolder> countDownViewList;

    public void setCountDownTime(int sec) {
        for (CountDownHolder holder : countDownViewList) {
            int h = (sec / 3600) % 24;
            int m = (sec % 3600) / 60;
            int s = sec % 3600 % 60;
            holder.countDown.setText(String.format("%s %s %s %s %s %s %s", surplusString, h, hourString, m, minuteString, s, secondString));
        }
    }

    public TravelProductDetailAdapter(Context context, onEvent event, GridLayoutManager manager, ItemDetail itemDetail, boolean isTrack) {
        countDownViewList = new ArrayList<>();
        this.context = context;
        this.event = event;
        this.itemDetail = itemDetail;
        this.isTrack = isTrack;
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return position < SECTION_COUNT ? manager.getSpanCount() : 1;
            }
        });
        init(context);
    }

    @Override
    public int getItemCount() {
        if (itemDetail == null) return 0;
        return SECTION_COUNT + items.size();
    }

    @Override
    public int getItemViewType(int position) {

        if (general == null) position += 1;

        switch (position) {

//            case 0:
//                return TYPE_BANNER;
            case 0:
                return TYPE_TITLE;
            case 1:
                return TYPE_PRICE;
            case 2:
                return TYPE_COUNT_DOWN;
            case 3:
                return TYPE_IMAGE;
            case 4:
                return TYPE_SECOND;
            case 5:
                return TYPE_PRODUCT_INFO;
            case 6:
                return TYPE_PRICE;
            case 7:
                return TYPE_SECOND;
            case 8:
                return TYPE_COUNT_DOWN;
            case 9:
                return TYPE_ITEM_HEADER;
            default:
                return TYPE_ITEM_LIST;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        switch (viewType) {
            case TYPE_BANNER:
                return new BannerHolder(inflater.inflate(R.layout.item_product_detail_banner, parent, false));
            case TYPE_TITLE:
                return new TitleHolder(inflater.inflate(R.layout.item_product_detail_travel_title, parent, false));
            case TYPE_PRICE:
                return new PriceHolder(inflater.inflate(R.layout.item_product_detail_travel_price, parent, false));
            case TYPE_COUNT_DOWN:
                return new CountDownHolder(inflater.inflate(R.layout.item_product_detail_travel_count_down, parent, false));
            case TYPE_IMAGE:
                return new ImageHolder(inflater.inflate(R.layout.item_product_detail_travel_image, parent, false));
            case TYPE_SECOND:
                return new SecondHolder(inflater.inflate(R.layout.item_product_detail_travel_second, parent, false));
            case TYPE_PRODUCT_INFO:
                return new ProductInfoHolder(inflater.inflate(R.layout.item_product_detail_travel_info, parent, false));
            case TYPE_ITEM_HEADER:
                return new ItemListHeader(inflater.inflate(R.layout.item_product_detail_travel_item_header, parent, false));
            case TYPE_ITEM_LIST:
            default:
                return new ItemListHolder(inflater.inflate(R.layout.holder_item_grid, parent, false));
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);

        if (holder instanceof CountDownHolder) {
            countDownViewList.remove(holder);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof BannerHolder && general != null) {

            ((BannerHolder) holder).click.setText(R.string.click_see_detail);
            ((BannerHolder) holder).isMember.setVisibility(general.getIsMember() ? View.VISIBLE : View.GONE);

            switch (general.getDiscType()) {
                case 1:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_1), general.getDiscPromote()));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_1));
                    break;

                case 2:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_2), general.getDiscCash().get(0), general.getDiscCash().get(1)));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_2));
                    break;

                case 3:
                    ((BannerHolder) holder).content.setText(String.format(context.getString(R.string.promote_content_3), general.getDiscCash()));
                    ((BannerHolder) holder).type.setText(context.getString(R.string.promote_type_3));
                    break;
            }

            if (general.getPassword() != null && general.getPassword().size() > 0) {
                ((BannerHolder) holder).password.setVisibility(View.VISIBLE);
                ((BannerHolder) holder).password.setText(general.getPassword().get(0));
                ((BannerHolder) holder).type.setText(R.string.checkout_input);
            } else {
                ((BannerHolder) holder).password.setVisibility(View.GONE);
            }

            ((BannerHolder) holder).itemView.setOnClickListener(view -> event.onBannerClick(general));

        } else if (holder instanceof TitleHolder) {

            //name
            String titleDiscount = !discount.equals("") && info.getIs_hilife() != null && info.getIs_hilife().equals("t") ? String.format("%s%s%s!", downDiscount, discountString, discString) : "";
            Spannable spannable = new SpannableString(titleDiscount + info.getName());
            spannable.setSpan(new ForegroundColorSpan(Color.RED), 0, titleDiscount.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            ((TitleHolder) holder).name.setText(spannable, TextView.BufferType.SPANNABLE);

            //subTitle
            ((TitleHolder) holder).subTitle.setText(info.getSubtitle());

        } else if (holder instanceof PriceHolder) {

            //price
            ((PriceHolder) holder).price.setText(String.format("$%s", info.getPrice_title() > 0 ? info.getPrice_title() : info.getPrice()));
            ((PriceHolder) holder).up.setVisibility(info.is_priceup() ? View.VISIBLE : View.GONE);


            //notaxString
            if (info.getWithout_is_notax() != null && info.getWithout_is_notax().equals("t")) {
                ((PriceHolder) holder).notax.setText(String.format("%s$%s", notaxString, info.getWithout_notax_price()));
            } else {
                ((PriceHolder) holder).notax.setVisibility(View.GONE);
            }

            //priceFakeString
            ((PriceHolder) holder).priceFake.setText(String.format("%s：%s%s", priceFakeString, info.getPrice_fake(), dollarsString));

            //discountString
            ((PriceHolder) holder).discount.setText(String.format("%s:%s%s", discountString, discount, discString));

            //bonus amt
            if (info.getBonus_amt() == 0) {
                ((PriceHolder) holder).bonusAmt.setVisibility(View.GONE);
                ((PriceHolder) holder).bonusAmtUp.setVisibility(View.GONE);
            } else {
                ((PriceHolder) holder).bonusAmt.setVisibility(View.VISIBLE);
                ((PriceHolder) holder).bonusAmtUp.setVisibility(View.VISIBLE);
                ((PriceHolder) holder).bonusAmt.setText(String.format(bonusAmtString, info.getBonus_amt()));
            }

            //i want buy
            ((PriceHolder) holder).iWantBuy.setVisibility(position == 1 && online.getIs_stock() && !(getTime(online.getDate_online()) > date.getTime()) ? View.VISIBLE : View.GONE);
            ((PriceHolder) holder).iWantBuy.setOnClickListener(view -> {
                if (online.getIs_stock()) event.onBuyClick();
            });

            holder.itemView.setOnClickListener(view -> {
                if (online.getIs_stock()) event.onBuyClick();
            });

        } else if (holder instanceof CountDownHolder) {

            countDownViewList.add(((CountDownHolder) holder));
            String buyItems = info.getBuy_items();
            Spannable buyIteSpannable = new SpannableString(String.format("%s %s / ", favorString, buyItems));
            buyIteSpannable.setSpan(new ForegroundColorSpan(Color.RED), favorString.length(), favorString.length() + buyItems.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            ((CountDownHolder) holder).buyItems.setText(buyIteSpannable);

        } else if (holder instanceof ImageHolder) {

            List<Img> imgList = new ArrayList<>();
            Img img = new Img();
            img.setUrl(info.getImg1_url());
            imgList.add(img);


            if (itemDetail.getImg() != null && itemDetail.getImg().size() != 0) {
                imgList.addAll(itemDetail.getImg());
                ((ImageHolder) holder).imgViewPager.setAdapter(new ImgPagerAdapter(context, imgList));
                ((ImageHolder) holder).indicator.setViewPager(((ImageHolder) holder).imgViewPager);
            } else {
                ((ImageHolder) holder).imgViewPager.setAdapter(new ImgPagerAdapter(context, imgList));
                ((ImageHolder) holder).indicator.setVisibility(View.GONE);
            }

        } else if (holder instanceof SecondHolder) {

            ((SecondHolder) holder).addToCart.setVisibility(View.GONE);
            ((SecondHolder) holder).buyNow.setVisibility(View.GONE);
            ((SecondHolder) holder).nextTime.setVisibility(View.GONE);
            ((SecondHolder) holder).notSale.setVisibility(View.GONE);
            ((SecondHolder) holder).contact.setVisibility(View.GONE);

            ((SecondHolder) holder).addToCart.setOnClickListener(view -> event.onAddToCartClick());
            ((SecondHolder) holder).buyNow.setOnClickListener(view -> event.onBuyClick());

            if (online.getIs_stock() && getTime(online.getDate_online()) <= date.getTime()) {

                if (!online.getChannel_id().equals("13") && !info.getIs_hilife_shop().equals("t")) {
                    ((SecondHolder) holder).addToCart.setVisibility(View.VISIBLE);
                }

                if (isTravelTag || (itemDetail.getInfo().getIs_hilife_shop() != null && itemDetail.getInfo().getIs_hilife_shop().equals("t"))) {
                    ((SecondHolder) holder).addToCart.setVisibility(View.GONE);
                }

                if (online.getChannel_id().equals("13")) {
                    ((SecondHolder) holder).contact.setVisibility(View.VISIBLE);
                }

                ((SecondHolder) holder).buyNow.setVisibility(View.VISIBLE);
            } else if (online.getIs_stock() && getTime(online.getDate_online()) > date.getTime()) {
                ((SecondHolder) holder).notSale.setVisibility(View.VISIBLE);
            } else {
                ((SecondHolder) holder).nextTime.setVisibility(View.VISIBLE);
            }

            ((SecondHolder) holder).track.setImageResource(isTrack ? R.mipmap.like_active : R.mipmap.like64x64);
            ((SecondHolder) holder).track.setOnClickListener(view -> event.onTrackClick());
            ((SecondHolder) holder).share.setOnClickListener(view -> event.shareItem());

        } else if (holder instanceof ProductInfoHolder) {

            Spanned html;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                html = Html.fromHtml(itemDetail.getDeliver_notic(), Html.FROM_HTML_MODE_LEGACY);
            } else {
                html = Html.fromHtml(itemDetail.getDeliver_notic());
            }

            ((ProductInfoHolder) holder).deliverNotice.setText(html);

            settingYoutubeWebView(((ProductInfoHolder) holder).youtube1, info.getYoutube_url1());
            settingYoutubeWebView(((ProductInfoHolder) holder).youtube2, info.getYoutube_url2());
            settingWebView(((ProductInfoHolder) holder).content, info.getContent());
            settingWebView(((ProductInfoHolder) holder).buyReason, info.getBuy_reason());

            if (info.getMade_in() != null && !info.getMade_in().equals("")) {
                ((ProductInfoHolder) holder).madeIn.setText(info.getMade_in());
            }

            if (info.getItem_state() != null && !info.getItem_state().equals("")) {
                ((ProductInfoHolder) holder).itemState.setText(info.getItem_state());
            }

            settingWebView(((ProductInfoHolder) holder).specification, info.getSpecification());
            settingWebView(((ProductInfoHolder) holder).returnNotice, itemDetail.getReturn_notice());

        } else if (holder instanceof ItemListHolder) {

            int itemPosition = position - SECTION_COUNT;
            if (itemPosition < 0 || items == null || items.size() == 0) return;

            ItemList itemList = items.get(itemPosition);

            String imgUrl = itemList.getPimg_m() == null || itemList.getPimg_m().equals("") ? itemList.getPimg_m() : itemList.getPimg();
            Glide.with(context).load(imgUrl)
                    .centerCrop()
                    .placeholder(R.mipmap.bg_download)
                    .into(((ItemListHolder) holder).thumb);

            ((ItemListHolder) holder).stock.setVisibility(itemList.getStock().equals("0") || itemList.getStock().equals("") ? View.VISIBLE : View.GONE);

            ((ItemListHolder) holder).name.setText(itemList.getPname());
            ((ItemListHolder) holder).priceFake.setText(String.format("$%s", itemList.getPrice_fake()));
            Paint paint = ((ItemListHolder) holder).priceFake.getPaint();
            paint.setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            paint.setAntiAlias(true);

            if (itemList.getPrice_title() != null && !itemList.getPrice_title().equals("0") && itemList.getIs_priceup().equals("1")) {
                ((ItemListHolder) holder).priceUp.setVisibility(View.VISIBLE);
                ((ItemListHolder) holder).priceTitle.setText(String.format("$%s", itemList.getPrice_title()));
            } else {
                ((ItemListHolder) holder).priceUp.setVisibility(View.GONE);
                ((ItemListHolder) holder).priceTitle.setText(String.format("$%s", itemList.getPrice()));
            }

            holder.itemView.setOnClickListener(v -> event.onItemListClick(itemList));
        }
    }

    private class BannerHolder extends RecyclerView.ViewHolder {

        TextView type;
        TextView password;
        TextView content;
        TextView click;
        TextView isMember;

        BannerHolder(View itemView) {
            super(itemView);
            type = (TextView) itemView.findViewById(R.id.type);
            password = (TextView) itemView.findViewById(R.id.password);
            content = (TextView) itemView.findViewById(R.id.content);
            click = (TextView) itemView.findViewById(R.id.click);
            isMember = (TextView) itemView.findViewById(R.id.isMember);
        }
    }

    private class TitleHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView subTitle;

        TitleHolder(View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.name);
            subTitle = (TextView) itemView.findViewById(R.id.subTitle);
        }
    }

    private class PriceHolder extends RecyclerView.ViewHolder {

        TextView price;
        TextView up;
        TextView notax;
        TextView priceFake;
        TextView discount;
        TextView bonusAmt;
        TextView bonusAmtUp;
        Button iWantBuy;

        PriceHolder(View itemView) {
            super(itemView);
            price = (TextView) itemView.findViewById(R.id.price);
            up = (TextView) itemView.findViewById(R.id.up);
            notax = (TextView) itemView.findViewById(R.id.notax);
            priceFake = (TextView) itemView.findViewById(R.id.priceFake);
            discount = (TextView) itemView.findViewById(R.id.discount);
            bonusAmt = (TextView) itemView.findViewById(R.id.bonusAmt);
            bonusAmtUp = (TextView) itemView.findViewById(R.id.bonusAmtUp);
            iWantBuy = (Button) itemView.findViewById(R.id.iWantBuy);
        }
    }

    private class CountDownHolder extends RecyclerView.ViewHolder {

        TextView buyItems;
        TextView countDown;

        CountDownHolder(View itemView) {
            super(itemView);

            buyItems = (TextView) itemView.findViewById(R.id.text_view_buy_items);
            countDown = (TextView) itemView.findViewById(R.id.text_view_count_down);
        }
    }

    private class ImageHolder extends RecyclerView.ViewHolder {

        ViewPager imgViewPager;
        CircleIndicator indicator;

        ImageHolder(View itemView) {
            super(itemView);

            imgViewPager = (ViewPager) itemView.findViewById(R.id.imgViewPager);
            indicator = (CircleIndicator) itemView.findViewById(R.id.indicator);
        }
    }

    private class SecondHolder extends RecyclerView.ViewHolder {

        Button addToCart;
        Button buyNow;
        TextView notSale;
        Button nextTime;
        View contact;
        ImageView track, share;

        SecondHolder(View itemView) {
            super(itemView);

            addToCart = (Button) itemView.findViewById(R.id.addToCart);
            buyNow = (Button) itemView.findViewById(R.id.buyNow);
            notSale = (TextView) itemView.findViewById(R.id.notSale);
            nextTime = (Button) itemView.findViewById(R.id.nextTime);
            contact = itemView.findViewById(R.id.contact);
            track = (ImageView) itemView.findViewById(R.id.image_view_favorite);
            share = (ImageView) itemView.findViewById(R.id.share);
        }
    }

    private class ProductInfoHolder extends RecyclerView.ViewHolder {

        View expectDeliverLayout;
        TextView deliverNotice;
        WebView youtube1;
        WebView youtube2;
        WebView content;
        WebView buyReason;
        TextView madeIn;
        TextView itemState;
        WebView specification;
        WebView returnNotice;

        ProductInfoHolder(View itemView) {
            super(itemView);
            expectDeliverLayout = itemView.findViewById(R.id.expectDeliverLayout);
            deliverNotice = (TextView) itemView.findViewById(R.id.deliverNotice);
            youtube1 = (WebView) itemView.findViewById(R.id.youtobe1);
            youtube2 = (WebView) itemView.findViewById(R.id.youtobe2);
            content = (WebView) itemView.findViewById(R.id.content);
            buyReason = (WebView) itemView.findViewById(R.id.buyReason);
            madeIn = (TextView) itemView.findViewById(R.id.madeIn);
            itemState = (TextView) itemView.findViewById(R.id.itemState);
            specification = (WebView) itemView.findViewById(R.id.specification);
            returnNotice = (WebView) itemView.findViewById(R.id.returnNotice);
        }
    }

    private class ItemListHeader extends RecyclerView.ViewHolder {

        ItemListHeader(View itemView) {
            super(itemView);
        }
    }

    private class ItemListHolder extends RecyclerView.ViewHolder {

        ImageView thumb;
        ImageView stock;
        TextView name;
        TextView priceFake;
        TextView priceTitle;
        TextView priceUp;

        ItemListHolder(View itemView) {
            super(itemView);
            thumb = (ImageView) itemView.findViewById(R.id.thumb);
            stock = (ImageView) itemView.findViewById(R.id.stock);
            name = (TextView) itemView.findViewById(R.id.name);
            priceFake = (TextView) itemView.findViewById(R.id.priceFake);
            priceTitle = (TextView) itemView.findViewById(R.id.priceTitle);
            priceUp = (TextView) itemView.findViewById(R.id.priceUp);
        }
    }
}
