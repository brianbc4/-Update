package com.crazymike.product.detail.alert;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;

import com.crazymike.R;
import com.crazymike.models.ItemDetail;
import com.crazymike.product.detail.adapter.SalesAdapter;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by ChaoJen on 2016/12/6.
 */

public class SalesDialog implements SalesAdapter.Listener{

    private View salesView;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    @BindView(R.id.recycler_view_sales) RecyclerView recyclerViewSales;

    public SalesDialog(Context context, ItemDetail itemDetail) {

        this.dialogBuilder = new AlertDialog.Builder(context);

        salesView = LayoutInflater.from(context).inflate(R.layout.dialog_sales, null);
        ButterKnife.bind(this, salesView);

        recyclerViewSales.setLayoutManager(new LinearLayoutManager(context));
        recyclerViewSales.setAdapter(new SalesAdapter(context, itemDetail, this));

        dialogBuilder.setView(salesView);
        dialog = dialogBuilder.create();
    }

    public void showDialog() {
        dialog.show();
    }

    @Override
    public void onCancelClick() {
        dialog.dismiss();
    }
}
