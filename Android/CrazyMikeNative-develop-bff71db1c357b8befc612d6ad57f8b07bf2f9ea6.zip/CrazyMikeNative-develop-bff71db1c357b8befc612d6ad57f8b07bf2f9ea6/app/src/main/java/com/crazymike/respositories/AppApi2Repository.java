package com.crazymike.respositories;

import android.os.Build;

import com.crazymike.CrazyMike;
import com.crazymike.api.NetworkService;
import com.crazymike.api.response.appapi2.BaseRes;
import com.crazymike.api.response.appapi2.GetAppVersion;
import com.crazymike.api.response.appapi2.GetCueSheetRes;
import com.crazymike.util.PreferencesKey;
import com.crazymike.util.PreferencesTool;

import rx.Observable;

public class AppApi2Repository {

    private static AppApi2Repository INSTANCE = new AppApi2Repository();

    private AppApi2Repository() {

    }

    public static AppApi2Repository getInstance() {
        return INSTANCE != null ? INSTANCE : (INSTANCE = new AppApi2Repository());
    }

    public Observable<Object> addDeviceToken(String token){
        return NetworkService.getInstance().getAppApi2().addDeviceToken(String.format("Android %s", Build.VERSION.RELEASE),
                Build.MODEL,
                token,
                PreferencesTool.getInstance().get( PreferencesKey.MEMBER_ID, String.class),
                CrazyMike.IMEI());
    }

    public Observable<GetCueSheetRes> getCueSheet(){
        return NetworkService.getInstance().getAppApi2().getCueEvent("android");
    }

    public Observable<Object> clickEvent(String id, String token){
        return NetworkService.getInstance().getAppApi2().clickEvent(id, token);
    }

    public Observable<GetAppVersion> getAppVersion(){
        return NetworkService.getInstance().getAppApi2().getAppVersion();
    }

    public Observable<BaseRes> addPushItem(String token, String times){
        return NetworkService.getInstance().getAppApi2().addPushItem(token, times);
    }
}
