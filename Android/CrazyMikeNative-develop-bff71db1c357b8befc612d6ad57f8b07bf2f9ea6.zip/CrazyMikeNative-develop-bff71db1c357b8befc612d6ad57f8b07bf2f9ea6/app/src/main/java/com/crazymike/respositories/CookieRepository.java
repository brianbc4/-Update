package com.crazymike.respositories;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import com.crazymike.util.PreferencesKey;
import com.crazymike.util.PreferencesTool;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import rx.Observable;
import rx.Subscriber;

public class CookieRepository {

    public static final String TAG = "CookieRepository";
    private static CookieRepository INSTANCE = new CookieRepository();
    private List<Cookie> cookieList;
    private boolean isLogin;

    private Observable<CookieRepository> cookieChangeObservable;
    private Subscriber<? super CookieRepository> cookieChangeSubscriber;

    private CookieRepository() {
        cookieList = new ArrayList<>();
    }

    public static CookieRepository getInstance() {
        return INSTANCE != null ? INSTANCE : (INSTANCE = new CookieRepository());
    }

    public void initial(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            CookieSyncManager.createInstance(context);
        }
    }

    public Observable<CookieRepository> getCookieObservable() {
        if (cookieChangeObservable == null) {
            cookieChangeObservable = Observable.create((Observable.OnSubscribe<CookieRepository>) subscriber -> cookieChangeSubscriber = subscriber).share();
        }
        return cookieChangeObservable;
    }

    public CookieJar getCookieJar() {
        return new CookieJar() {
            @Override
            public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {

                cookieList.clear();

                cookieList.add(new Cookie.Builder()
                        .name("channel")
                        .value("app")
                        .domain("appapi2.crazymike.tw")
                        .path("/")
                        .build());

                String cookiesTemp = CookieManager.getInstance().getCookie(url.host());
                if (cookiesTemp != null) {
                    for (String cookie : cookiesTemp.split(";")) {
                        cookieList.add(Cookie.parse(url, cookie));
                    }
                }

                isLogin = checkLogin(cookieList);
                if (cookieChangeSubscriber != null) cookieChangeSubscriber.onNext(INSTANCE);
                Log.i(TAG, "saveFromResponse");
            }

            @Override
            public List<Cookie> loadForRequest(HttpUrl url) {
                cookieList.clear();

                cookieList.add(new Cookie.Builder()
                        .name("channel")
                        .value("app")
                        .domain("appapi2.crazymike.tw")
                        .path("/")
                        .build());

                String cookies = CookieManager.getInstance().getCookie(url.host());
                if (cookies != null) {
                    for (String cookie : cookies.split(";")) {
                        cookieList.add(Cookie.parse(url, cookie));
                    }
                }

                return cookieList;
            }
        };
    }

    private boolean checkLogin(List<Cookie> cookieList) {

        boolean user = false, token = false, sig = false, time = false;

        try {


            for (Cookie cookie : cookieList) {

                if (cookie != null && cookie.name() != null && cookie.name().equals("user") && cookie.value() != null && !cookie.value().equals("")) {
                    user = true;
                    PreferencesTool.getInstance().put(PreferencesKey.LOGIN_USER, cookie.value());
                }

                if (cookie != null && cookie.name() != null && cookie.name().equals("token") && cookie.value() != null && !cookie.value().equals("")) {
                    token = true;
                }

                if (cookie != null && cookie.name() != null && cookie.name().equals("sig") && cookie.value() != null && !cookie.value().equals("")) {
                    sig = true;
                }

                if (cookie != null && cookie.name() != null && cookie.name().equals("time") && cookie.value() != null && !cookie.value().equals("")) {
                    time = true;
                }

                if (cookie != null && cookie.name() != null && cookie.name().equals("member_id") && cookie.value() != null && !cookie.value().equals("")) {
                    PreferencesTool.getInstance().put(PreferencesKey.MEMBER_ID, cookie.value());
                }
            }

            return user && token && sig && time;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public void setIsLogin(boolean isLogin) {
        this.isLogin = isLogin;
    }

    public boolean isLogin() {
        return isLogin;
    }

    public void clearCookies() {

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Log.d(TAG, "Using clearCookies code for API >=" + String.valueOf(Build.VERSION_CODES.LOLLIPOP));
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
            } else {
                Log.d(TAG, "Using clearCookies code for API <" + String.valueOf(Build.VERSION_CODES.LOLLIPOP));
                CookieManager cookieManager = CookieManager.getInstance();
                cookieManager.removeAllCookie();
                cookieManager.removeSessionCookie();
                CookieSyncManager.getInstance().sync();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void checkWebViewCookie(String url) {
        try {
            String cookies = CookieManager.getInstance().getCookie(url);
            String[] cookiesList = cookies.split(";");
            cookieList.clear();
            for (String c : cookiesList) {
                String[] pair = c.split("=");
                cookieList.add(new Cookie.Builder()
                        .name(pair[0].trim())
                        .value(pair[1].trim())
                        .domain("appapi2.crazymike.tw")
                        .path("/")
                        .build());
            }

            isLogin = checkLogin(cookieList);
            if (cookieChangeSubscriber != null) cookieChangeSubscriber.onNext(INSTANCE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}