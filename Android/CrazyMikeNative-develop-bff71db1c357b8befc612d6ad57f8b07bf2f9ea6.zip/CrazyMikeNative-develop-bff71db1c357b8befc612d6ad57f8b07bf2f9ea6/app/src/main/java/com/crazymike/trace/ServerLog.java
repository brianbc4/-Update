package com.crazymike.trace;

import com.crazymike.api.NetworkService;
import com.crazymike.util.PreferencesKey;
import com.crazymike.util.PreferencesTool;
import com.crazymike.util.RxUtil;
import com.crazymike.util.UrlParser;

/**
 * Created by ChaoJen on 2017/1/5.
 */

public class ServerLog {

    public void send(String url) {
        NetworkService.getInstance().getServerApi().sendServerLog(
                UrlParser.getSession(url),
                PreferencesTool.getInstance().get(PreferencesKey.LOGIN_USER, String.class),
                UrlParser.getTarget(url),
                UrlParser.getParams(url)).compose(RxUtil.mainAsync())
                .subscribe(baseResponse -> {}, Throwable::printStackTrace);
    }
}
