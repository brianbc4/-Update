package com.crazymike.trace;

import android.support.design.widget.TabLayout;

import com.crazymike.models.Banner;
import com.crazymike.models.ItemList;
import com.crazymike.models.RotateJson;
import com.crazymike.respositories.ProductRepository;

/**
 * Created by ChaoJen on 2016/11/18.
 *
 * return format "Tcode" & "Fcode" for traceApi use
 */

public class TraceQueryRule {

    public static String getTagTcode(int position) {
        String tagId;
        if(position == 0) {
            //trace user click Home tab, but there have no tagId
            return "HomePage";
        }else {
            tagId = ProductRepository
                    .getInstance()
                    .getUpSideMenus()
                    .get(position)
                    .getUrl()
                    .split("tag-")[1]
                    .split("/")[0];
        }
        return "T" + tagId;
    }

    public static String getTagFcode() {
        return "S34";
    }

    public static String getBannerTcode(Banner banner, RotateJson rotateJson) {
        return (rotateJson.getTcode() != null && rotateJson.getTcode().length() != 0) ?
                rotateJson.getTcode() : "B" + banner.getBanner_id();
    }

    public static String getBannerFcode(Banner banner) {
        return "B" + banner.getBanner_id();
    }

    public static String getItemListTcode(ItemList itemList) {
        return "I" + itemList.getOnline_id();
    }

    public static String getItemListFcode(String tagId) {
        return tagId.equals("5") ? "CI5" : "TI" + tagId;
    }
}
