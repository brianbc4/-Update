package com.crazymike.trace;

import com.crazymike.api.FUNC;
import com.crazymike.api.NetworkService;
import com.crazymike.api.TFUNC;
import com.crazymike.models.Banner;
import com.crazymike.models.ItemDetail;
import com.crazymike.models.ItemList;
import com.crazymike.models.RotateJson;
import com.crazymike.util.RxUtil;

/**
 * Created by ChaoJen on 2016/11/18.
 */

public class UserBehaviorTracer {

    public void onPageChanged(int position) {
        NetworkService.getInstance().getTraceApi().traceClick(
                FUNC.TRACE,
                TFUNC.TRACE,
                TraceQueryRule.getTagTcode(position),
                TraceQueryRule.getTagFcode())
                .compose(RxUtil.mainAsync())
                .subscribe(traceResponse -> {}, Throwable::printStackTrace);
    }

    //trace user click MLinkBanner, but the RotateJson of MLinkBanner has no tcode
    public void onBannerClick(Banner banner, RotateJson rotateJson) {
        NetworkService.getInstance().getTraceApi().traceClick(
                FUNC.TRACE,
                TFUNC.TRACE,
                TraceQueryRule.getBannerTcode(banner, rotateJson),
                TraceQueryRule.getBannerFcode(banner))
                .compose(RxUtil.mainAsync())
                .subscribe(traceResponse -> {}, Throwable::printStackTrace);
    }

    public void onItemListClick(ItemList itemList, String tag) {
        NetworkService.getInstance().getTraceApi().traceClick(
                FUNC.TRACE,
                TFUNC.TRACE,
                TraceQueryRule.getItemListTcode(itemList),
                TraceQueryRule.getItemListFcode(tag))
                .compose(RxUtil.mainAsync())
                .subscribe(traceResponse -> {}, Throwable::printStackTrace);
    }

    public void onItemDetailDisplay(ItemDetail itemDetail) {
        NetworkService.getInstance().getTraceApi().traceDisplay(
                FUNC.TRACE,
                TFUNC.ITEM,
                itemDetail.getOnline().getOnline_id(),
                itemDetail.getOnline().getChannel_id())
                .compose(RxUtil.mainAsync())
                .subscribe(traceResponse -> {}, Throwable::printStackTrace);
    }
}
