package com.crazymike.util;

public class ActionName {

    public static final String CHANNEL = "CHANNEL";
    public static final String TAG = "TAG";

    public static final String SEARCH_KEY = "SEARCH_KEY";
}
