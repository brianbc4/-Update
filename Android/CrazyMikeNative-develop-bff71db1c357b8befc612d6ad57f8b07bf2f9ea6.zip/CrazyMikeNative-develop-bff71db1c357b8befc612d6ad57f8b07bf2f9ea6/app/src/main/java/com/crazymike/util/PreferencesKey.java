package com.crazymike.util;

/**
 * Created by cuber on 2015/10/23.
 */
public enum PreferencesKey {
    GCM_TOKE, CUE_SHEET, MEMBER_ID, SHOW_NOTIFICATION_ID, LOGIN_TYPE, LOGIN_USER, LAST_PUSH
}
