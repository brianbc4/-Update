package com.crazymike.util;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ChaoJen on 2017/1/6.
 */

public class UrlParser {

    private static final String TAG = UrlParser.class.getSimpleName();

    public static String getSession(String url) {
        String sessionId = "";
        try {
            sessionId = android.webkit.CookieManager.getInstance().getCookie(url).split("PHPSESSID=")[1].split(";")[0];
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
        return sessionId;
    }

    public static String getTarget(String url) {
        String targetString = "";
        try {
            targetString = url.split("https://crazymike.tw/")[1].split("\\?")[0];
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
        return targetString;
    }

    public static String getParams(String url) {
        String paramsString = "";
        Map<String, String> params = new HashMap<>();
        String[] paramKeys = new String[]{"mkt", "mkt3", "partner", "affcode", "utm_medium", "utm_source", "utm_campaign"};
        for (int i = 0; i < paramKeys.length; i ++) {
            try {
                params.put(paramKeys[i], url.split(paramKeys[i] + "=")[1].split("&")[0]);
            }catch (Exception e) {
                params.remove(paramKeys[i]);
                Log.e(TAG, e.toString());
            }
        }

        for (int i = 0; i < paramKeys.length; i++) {
            if (params.get(paramKeys[i]) != null) {
                paramsString += paramKeys[i] + "=" + params.get(paramKeys[i]) + "&";
            }
        }

        try {
            paramsString = paramsString.substring(0, paramsString.length() - 1);
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
        return paramsString;
    }
}
