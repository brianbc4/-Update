package com.crazymike.web;

public class WebExtra {

    public static final String CHANNEL = "CHANNEL";
    public static final String TAG = "TAG";
    public static final String SUBTAG1 = "SUBTAG1";
    public static final String SUBTAG2 = "SUBTAG2";
    public static final String MSG = "MSG";
    public static final String URL = "URL";
}
