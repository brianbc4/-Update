package com.crazymike.web;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.crazymike.R;
import com.crazymike.alert.ShowAlertActivity;
import com.crazymike.base.BaseActivity;
import com.crazymike.models.Tag;
import com.crazymike.product.detail.ProductDetailActivity;
import com.crazymike.util.ActionName;
import com.orhanobut.logger.Logger;

import java.net.URISyntaxException;

public class WebViewActivity extends BaseActivity implements WebViewContract.View {

    private static final String TAG = "WebViewActivity";

    private static final String URL = "URL";
    private static final String TITLE = "TITLE";

    private String url;
    private boolean isPause = false;

    private WebViewPresenter presenter;
    private WebView webView;

    public static void startActivity(Context context, String url) {
        Intent intent = new Intent(context, WebViewActivity.class);
        intent.putExtra(URL, url);
        context.startActivity(intent);
    }

    public static void startActivity(Activity activity, String url, int requestCode) {
        Intent intent = new Intent(activity, WebViewActivity.class);
        intent.putExtra(URL, url);
        activity.startActivityForResult(intent, requestCode);
    }

    public static void startActivity(Activity activity, String url, String title, int requestCode) {
        Intent intent = new Intent(activity, WebViewActivity.class);
        intent.putExtra(URL, url);
        intent.putExtra(TITLE, title);
        activity.startActivityForResult(intent, requestCode);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra(URL);

        String title = getIntent().getStringExtra(TITLE);
        presenter = new WebViewPresenter(this);
        setContentView(R.layout.activity_web);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (title == null) {
            toolbar.setVisibility(View.GONE);
        } else {
            setSupportActionBar(toolbar);
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.setDisplayHomeAsUpEnabled(true);
                actionBar.setDisplayShowHomeEnabled(true);
                actionBar.setTitle(title);
            }
            toolbar.setNavigationOnClickListener(view -> finish());
        }


        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);

        findViewById(R.id.home).setOnClickListener(view -> finish());

        webView = (WebView) findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.clearCache(true);
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (isPause) return;
                progressBar.setVisibility(View.VISIBLE);
                if ( presenter.checkUrl(url)) {
                    view.stopLoading();
                    onBackPressed();
                }

                Logger.i(TAG, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (isPause) return;
                presenter.checkCookie(url);
                progressBar.setVisibility(View.GONE);
                Logger.i(TAG, url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                progressBar.setProgress(newProgress);
            }
        });

        toWebPage(url);

    }

    @Override
    protected void onResume() {
        super.onResume();
        isPause = false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        isPause = true;
    }

    @Override
    protected void onDestroy() {
        webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onBackClick() {
        finish();
    }

    @Override
    public void toProduct(String itemId) {
        if (isPause) return;
        if (url.contains("buy.asp?")) {
            onBackPressed();
            return;
        }
        ProductDetailActivity.startActivity(this, itemId, url);
    }

    @Override
    public void onToSpecialUrl(String url) {
        try {
            Intent intent = Intent.parseUri(url, 0);
            startActivity(intent);
            webView.goBack();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onShowAlert(String msg) {
        ShowAlertActivity.startActivity(this, msg);
    }

    @Override
    public void onToTagWebView(String url) {
        toWebPage(url);
    }

    @Override
    public void onToTagPage(Tag tag, int tagPosition, Tag subTag1, int subTag1Position, Tag subTag2, int subTag2Position) {
        Intent intent = new Intent();
        intent.setAction(ActionName.TAG);
        intent.putExtra(WebExtra.TAG, tag.getTag_id());
        intent.putExtra(WebExtra.URL, url);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void onToHomePage(String tagId) {
        Intent intent = new Intent();
        intent.setAction(ActionName.TAG);
        intent.putExtra(WebExtra.TAG, tagId);
        intent.putExtra(WebExtra.URL, url);
        setResult(RESULT_OK, intent);
        finish();
    }

    private void toWebPage(String url) {
        Uri uri = Uri.parse(url).buildUpon()
                .appendQueryParameter("channel", "app")
                .build();
        webView.loadUrl(Uri.decode(uri.toString()));
    }
}
