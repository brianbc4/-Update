package com.crazymike.web;

import com.crazymike.models.Tag;
import com.crazymike.respositories.CookieRepository;
import com.crazymike.respositories.ProductRepository;

import java.util.ArrayList;
import java.util.List;

class WebViewPresenter implements WebViewContract.Presenter {

    private static final String TAG = WebViewPresenter.class.getSimpleName();

    private WebViewContract.View view;
    private List<String> notNeedCheckUrl;

    WebViewPresenter(WebViewContract.View view) {
        this.view = view;
    }


    @Override
    public boolean isNeedCheck(String url) {
        if (notNeedCheckUrl == null) notNeedCheckUrl = new ArrayList<>();
        for (String u : notNeedCheckUrl) {
            if (url.equals(u)) return false;
        }
        return true;
    }

    @Override
    public boolean checkUrl(String url) {

        String msg = WebRule.isShowAlert(url);
        if (msg != null) {
            view.onShowAlert(msg);
        }

        if (WebRule.isClickBack(url)) {
            view.onBackClick();
            return true;
        }

        String itemId = WebRule.isProduct(url);
        if (itemId != null) {
            view.toProduct(itemId);
            return true;
        }

        String tag = WebRule.isTag(url);
        if (tag != null) {
            checkTagIsInUpsideMenu(tag, url);
        }

        if (WebRule.isSpecialUrl(url)) {
            view.onToSpecialUrl(url);
            return true;
        }

        return false;
    }

    @Override
    public void checkCookie(String url) {
        CookieRepository.getInstance().checkWebViewCookie(url);
    }

    private void checkTagIsInUpsideMenu(String tagId, String url) {

        ProductRepository.getInstance().getSubTag(tagId, new ProductRepository.OnGetSubTagCallback() {
            @Override
            public void getSubTag(Tag tag, int tagPosition, Tag subTag1, int subTag1Position, Tag subTag2, int subTag2Position) {
                view.onToTagPage(tag, tagPosition, subTag1, subTag1Position, subTag2, subTag2Position);
            }

            @Override
            public void getNothing() {
//                notNeedCheckUrl.add(url);
//                view.onToTagPage();
                view.onToHomePage(tagId);
            }
        });
    }
}
